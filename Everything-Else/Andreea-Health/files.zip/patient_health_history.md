# Patient Health History — Dana Andreea Zamfira
**DOB:** 11/08/1984 (41 years old, female)  
**Address:** 6, rue du Cimetière, LU-7313 Heisdorf, Luxembourg  
**CNS:** 1984 08 11 800 03  
**Last blood draw:** 06/03/2026

---

## 1. Chronic / Long-standing Conditions

- **Chronic constipation** — present for as long as she can remember, no identified cause
- **Migraines** — approximately twice a month, lifelong
- **Recurrent UTI (E. coli)** — began a few months before giving birth (~3 years ago); either never fully resolved or resurfaces every few months. Most recent confirmed episode: Feb 2026 (E. coli >100,000 UFC/ml). Treated with antibiotics. Resistant to Ampicillin and Ciprofloxacin; sensitive to most other antibiotics including Nitrofurantoine and Fosfomycine.
- **Elevated TSH** — persistently above range across multiple tests (5.9 in Sept 2025, 5.5 in Feb 2026). T4 free normal. Thyroid antibodies negative. Being monitored by Dr Makke.
- **Elevated prolactin** — 34.8 ng/mL (range 5.2–26.5). Confirmed active after PEG test (30.8 ng/mL, macro-prolactin only 11.5%). History of very high prolactin in Feb 2023 (91.4 ng/mL).

---

## 2. Medical History / Past Events

- **Rathke's cleft cyst** on the pituitary gland — discovered approximately 2 years ago
- **Gave birth** approximately 2.5 years ago
- **Knee surgery** — more than a decade ago (right knee)
- **Mounjaro (tirzepatide)** — used for weight loss approximately 1 year ago; lost ~15 kg. Stopped approximately 1 year ago.
- **EBV (Epstein-Barr / Mononucleosis)** — past infection confirmed (IgG positive, IgM negative — old infection)
- **Varicella Zoster** — immune (IgG positive)
- **Rubella** — immune (IgG positive)

---

## 3. Current / Recent Symptoms

- **Recurring oral thrush (oral candidiasis)** — red inflamed patches on tongue with white coating around them and open sores; started around the time of stopping Mounjaro (~1 year ago); recurs with no obvious trigger, though likely linked to repeated antibiotic courses for UTI. Nausea coincides with tongue episodes (possible esophageal involvement). **Dentist assessment: consistent with oral thrush.**
- **Weakness and pain in right arm and right leg** — started approximately 3 months ago; right leg was still painful last week (ongoing, not resolved). One episode of transient numbness in right leg when getting up suddenly. Neurologist attributed leg issues to old knee surgery — but this does not account for the bilateral arm symptoms that have since developed. Physiotherapist found one leg shorter than the other, causing compensatory loading throughout the spine.
- **Bilateral arm burning** — developed over the past ~4 weeks. Whole arm, both sides. No visible skin change (pruritus sine materia). Burning felt internally. Worsens at night; varies day to day. Strongest at the upper arms near the shoulder; present throughout the whole arm. Right side originally more prominent, now bilateral.
- **Buttocks burning** — new symptom. Worse when sitting (worsens with prolonged sitting, better when lying flat). Piriformis self-test negative — buttocks burning is likely coming from lumbar/lower spinal involvement rather than a tight piriformis muscle.
- **Worsening nausea and vomiting** — pre-existing mild nausea significantly worsened approximately one week after starting new medications (Euthyrox 75mcg, Progyn Intim oral, multivitamin, B vitamin). One episode of vomiting. Nausea constant and triggered after eating. Likely caused by oral estradiol inducing GERD + vitamins taken on empty stomach.
- **Burning sensation in throat/chest and stomach** — new since starting medications; triggered by mildly spicy food previously tolerated. Consistent with GERD from oral estradiol relaxing the lower esophageal sphincter, compounded by taking stomach-irritating medications without food.

---

## 4. Recent Investigations (last 1–2 months)

| Investigation | Result / Finding |
|---|---|
| Thyroid ultrasound | No concerns |
| Mammogram | No concerns |
| Head CT scan | No concerns (approx. 2 months ago) |
| Brain MRI | No concerns (approx. 2 weeks ago — focused on pituitary gland; general brain appearance clear) |
| Pap smear | No concerns |
| Stool test (Feb 2026) | No blood detected (<20 ng/mL); H. pylori negative (Mar 2026) |
| ANA (anti-nuclear antibodies) | Negative |
| ANCA (vasculitis screen) | Negative |
| Rheumatoid factor | Negative (<20) |
| Anti-CCP2 | Negative (1.5) |
| HIV, Hep B, Hep C, Syphilis | All negative |
| Toxoplasmosis | No immunity |
| Parvovirus B19 | No immunity |
| CMV | Negative |

---

## 5. Key Blood Test Results (Feb–Mar 2026)

### 🔴 Outside Normal Range

| Test | Result | Normal Range | Note |
|---|---|---|---|
| TSH | 5.5 mUI/L | 0.35–4.5 | Persistently elevated |
| Prolactin | 34.8 ng/mL | 5.2–26.5 | Elevated; active after PEG test |
| Folate (B9) | 2.3 ng/mL | 3.0–17.6 | Below range |
| Vitamin D | 27.5 ng/mL | >30 | Mildly deficient |
| Parathormone | 38.4 pg/mL | 6.5–36.8 | Mildly elevated (linked to low Vit D) |
| FSH | 1.6 UI/L | 3.0–8.1 (follicular phase) | Low for cycle phase |
| CA 72-4 | 10.8 U/mL | <6.9 | Elevated tumour marker (Mar 2026) |
| GFR (DFG) | 89 mL/min | >90 | Mildly below target |

### 🟡 Within Range but Noteworthy

| Test | Result | Normal Range | Note |
|---|---|---|---|
| Ferritin | 11–13 ng/mL | 10–205 | Very low end; trending down |
| Vitamin B12 | 284 pg/mL | 189–883 | Low-normal end |
| HDL Cholesterol | 39 mg/dL | ~>50 for women | Low |
| IGF-1 | 94 ng/mL | 76–225 (age 41–50) | Within range but lower end |
| CRP | 4 mg/L | <5 | Just below threshold |

### ✅ Normal / Reassuring

| Test | Result | Note |
|---|---|---|
| CA 125 | 16 U/mL (<35) | Ovarian marker — normal |
| CA 19-9 | 12 U/mL (<37) | Pancreatic/GI marker — normal |
| CEA | 1.4 ng/mL (<5) | Colorectal marker — normal |
| Alpha-fetoprotein | <2.0 ng/mL (<13) | Normal |
| Full blood count | All normal | WBC, RBC, haemoglobin, platelets all in range |
| Liver enzymes | All normal | GOT, GPT, GGT all in range |
| Kidney function | Essentially normal | Creatinine, urea normal |
| Blood glucose / HbA1c | Normal | 90 mg/dL; HbA1c 5.2% |
| Thyroid antibodies | Negative | Anti-TPO <1.0; Anti-TG <1.0 |
| Electrolytes | All normal | Sodium, potassium, calcium, magnesium all in range |
| Complement (CH50, C3, C4) | All normal | |
| Protein electrophoresis | Normal | No monoclonal gammopathy |

---

## 6. Clinical Self-Test Results (April 2026)

Five clinical tests performed at home to help differentiate between spinal cord compression, nerve root compression, piriformis syndrome, and myelopathy.

| Test | Result | Interpretation |
|---|---|---|
| **Lhermitte's sign** (chin-to-chest: electric shock down spine?) | ✅ Negative | No electric shock sensation. Reassuring — makes active acute cervical cord compression less likely |
| **Arm abduction relief** (hand on head: arm symptoms improve?) | Negative | Symptoms unchanged. Doesn't rule out radiculopathy (test has low sensitivity), but no clean pinched-nerve signal |
| **Piriformis FAIR test** (cross-body knee: reproduces buttock burning?) | ✅ Negative | Buttocks burning not piriformis muscle. Likely coming from lower spine / lumbar nerve roots |
| **Grip and release test** (fist open/close × 10 sec) | ✅ 26 cycles | Above normal threshold of 20. Normal hand fine motor function — reassuring against significant myelopathy |
| **Sitting vs lying** (buttocks worse sitting?) | ⚠️ Worse sitting | Lumbar spinal pressure pattern. Consistent with lower spine / lumbar involvement for the buttocks symptom |

**Overall interpretation:** The combination of negative Lhermitte's and normal grip test is meaningfully reassuring — they point away from acute, significant cervical cord compression. The sitting-worsening buttocks symptom with negative piriformis test suggests a lumbar/lower spinal contribution. The most likely picture is multi-level spinal involvement (cervical + lumbar) driven by her documented musculoskeletal imbalance, probably without acute cord damage currently.

| Medication | Dose / Route | Prescribed for |
|---|---|---|
| Euthyrox (levothyroxine) | 75mcg oral (increased from 50mcg) | Subclinical hypothyroidism |
| Progyn Intim (estradiol) | Oral | UTI / vaginal health |
| Multivitamin | Oral | Nutritional deficiencies |
| Vitamin B complex | Oral | Folate / B12 deficiency |

**⚠️ Note on timing:** All medications currently taken together on an empty stomach in the morning. This is incorrect for all except Euthyrox — oral estradiol and vitamins should be taken with food, and must be separated from Euthyrox by at least 4 hours to avoid blocking its absorption.

**⚠️ Note on drug interaction:** Oral estradiol raises thyroxine-binding globulin (TBG), which reduces the free fraction of circulating T4. This means starting oral estradiol simultaneously with a Euthyrox dose increase makes the net thyroid effect unpredictable. TSH recheck recommended ~12 weeks after both changes.
---

## 8. Treating Physicians (as referenced in lab reports)

- **Dr Feher** — primary physician (ordered most panels)
- **Dr Makke** — thyroid follow-up
- **Dr Poterasu** — ordered endocrine / pituitary panel
- Neurologist consulted for arm/leg symptoms (name not recorded)
- Physiotherapist consulted for musculoskeletal issues (name not recorded)
