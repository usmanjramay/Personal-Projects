# Research Findings & Medical Analysis
**Prepared:** March 2026  
**Patient:** Dana Andreea Zamfira, 41F  
**Purpose:** Research summary to support informed discussion with treating physicians

> ⚠️ *This document summarises research findings and is intended to help formulate questions for medical appointments. It does not constitute medical advice and should always be reviewed in context with a qualified physician.*

---

## 1. Elevated CA 72-4 (10.8 U/mL, normal <6.9)

### What is CA 72-4?
CA 72-4 is a tumour-associated glycoprotein that can be elevated in certain cancers (gastric, ovarian, colorectal, pancreatic, endometrial) but is also frequently elevated in non-cancerous conditions. A single mildly elevated result is not a diagnosis.

---

### Study 1 — False Positives in Clinical Context (Oxford Academic, 2024)
**Setup:** Retrospective analysis of 1,290 laboratory CA 72-4 tests from 2017–2019. Researchers identified confirmed false positives (elevated result, no cancer found) and examined their underlying conditions.

**Key findings:**
- 44 of 204 elevated results were clearly false positives
- Her result (10.8) falls in Group 1 (7–14 U/mL) — the mildest elevation band
- In Group 1, **viral or bacterial infection was present in 60% of false positive patients**
- In true positive (cancer) cases, **88% had at least one other tumour marker elevated**
- Her CA 19-9, CA 125, CEA, and alpha-fetoprotein are all completely normal

---

### Study 2 — Long-term Follow-up of Raised CA 72-4 (Acquaint Publications)
**Setup:** 131 patients with raised CA 72-4 were given full investigations (gastroscopy, colonoscopy, CT, abdominal/pelvic MRI) and followed over 36 months alongside 706 controls.

**Key findings:**
- Malignancy found in only **5.3%** of those with raised CA 72-4 — not statistically different from controls (3.4%)
- At 36-month follow-up: **zero patients** in either group developed new malignancy
- This held true even for those with persistently elevated CA 72-4 throughout
- Conclusion from authors: a persistently raised or fluctuating CA 72-4 without symptoms should not prompt repeated extensive investigation

---

### Study 3 — CA 72-4 Screening in 7,757 Healthy Adults (Taiwan, 2019)
**Setup:** Large multicenter retrospective study. All participants had gastroscopy, CA 72-4, CEA, and CA 19-9 measured.

**Key findings:**
- 7.2% of healthy adults had elevated CA 72-4
- **Positive predictive value for gastric cancer: only 0.18%** (fewer than 2 per 1,000)
- Of 3 cancer cases found, 2 actually had CA 72-4 within normal range
- Only 1 patient had all three markers (CA 72-4, CEA, CA 19-9) elevated — and that patient had benign disease

---

### Cancer-by-Cancer Assessment

| Cancer | CA 72-4 Sensitivity | Companion Marker | Her Companion Marker |
|---|---|---|---|
| Gastric | 40–60% | CEA, CA 19-9 | Both normal ✅ |
| Ovarian | 47–80% (only 10% in early stage) | CA 125 | Normal ✅ |
| Colorectal | 20–41% | CEA | Normal ✅ |
| Pancreatic | 17–35% | CA 19-9 | Normal ✅ |
| Endometrial | ~54% | Pap smear | Clear ✅ |
| Lung | ~36% | CEA | Normal ✅ (note: no chest imaging done) |

**Key principle:** In genuine cancer cases, multiple markers tend to be elevated together. Her isolated elevation with all companion markers normal is strongly consistent with a false positive.

---

### Most Likely Explanation
Her **active recurring E. coli UTI** is the most plausible cause of the elevated CA 72-4, supported by Study 1 (infection present in 60% of false positives at her elevation level). Chronic constipation causing low-grade gut inflammation may also contribute.

### Recommended Questions for Doctor
1. *"Given her active recurring UTI and chronic constipation, could these alone explain the elevated CA 72-4?"*
2. *"Can we retest CA 72-4 after the UTI is fully treated and resolved to see if it normalises?"*
3. *"If it remains elevated after UTI resolution, would abdominal imaging be the appropriate next step?"*

---

## 2. Tongue Inflammation — Oral Thrush (Oral Candidiasis)

### Confirmed Assessment
**Dentist assessment: consistent with oral thrush (oral candidiasis).** This aligns with the clinical picture and the research findings below.

### Symptoms Presented
- Recurring red inflamed patches on the tongue
- White coating around the patches
- Open sores when the white material peels away
- Nausea coinciding with tongue episodes (suggesting possible esophageal involvement)
- Started around the time of stopping Mounjaro (~1 year ago)
- Recurs periodically with no obvious single trigger

### What is Oral Thrush?
Oral candidiasis is a fungal overgrowth of *Candida albicans* in the mouth. The classic presentation is white coating over red inflamed mucosa — scraping it away reveals the raw, sometimes bleeding surface underneath. It is benign and treatable, but tends to recur if the underlying trigger is not addressed.

### Why She Is Susceptible — Two Overlapping Factors

**Factor 1: Repeated antibiotic courses for UTI**
Each course of antibiotics for her recurrent E. coli UTI disrupts the normal oral microbiome, giving Candida the opportunity to overgrow. This is a well-established cause of oral thrush — sometimes called "antibiotic sore tongue". Given her UTI has been recurring for 3 years with multiple treatment courses, this is the most likely primary trigger. It is worth noting whether tongue flare-ups correlate with antibiotic courses specifically.

**Factor 2: Nutritional deficiency lowering mucosal defences**
Her confirmed low folate (below range) and borderline ferritin reduce mucosal resilience, making the tongue lining more vulnerable to infection and slower to heal. A study of 236 atrophic glossitis patients found vitamin B12 deficiency in 68% and ferritin deficiency in 14%, with most resolving within one month of supplementation. Her nutritional deficiencies are likely compounding the susceptibility created by the antibiotics.

### Nausea and Possible Esophageal Involvement
The nausea coinciding with tongue episodes is a notable additional symptom. Esophageal candidiasis (Candida spreading from the mouth to the esophagus) commonly causes nausea and a sensation of food being stuck. This is worth raising with the doctor, particularly if swallowing feels uncomfortable during episodes.

### Recommended Questions for Doctor
1. *"The dentist assessed her tongue symptoms as consistent with oral thrush. Should she be treated with antifungal medication (e.g. nystatin lozenges or a short course of fluconazole)?"*
2. *"Given the nausea coincides with tongue episodes, could there be esophageal candidiasis involvement? Does this change the treatment approach?"*
3. *"Her thrush appears to recur — likely triggered by repeated antibiotic courses for UTI. Is there a preventive strategy, such as taking an antifungal alongside antibiotics in future?"*
4. *"Should her low folate and borderline ferritin be supplemented to help restore mucosal defences and reduce recurrence?"*

---

## 3. Medication-Induced Nausea, Vomiting & GERD (New — March 2026)

### Context
Approximately one week after starting four new medications simultaneously, she developed significantly worsened nausea (constant, triggered immediately after eating), one episode of vomiting, and a new burning sensation in both the throat/chest and stomach when eating mildly spicy food she previously tolerated without issue.

### Most Likely Cause: Two Overlapping Mechanisms from Oral Estradiol

**Mechanism 1 — Oral estradiol triggering GERD**
Oral estrogen (Progyn Intim) is a well-documented cause of gastroesophageal reflux disease. Estrogen increases stomach acid production and relaxes the lower esophageal sphincter (LES) — the valve between the stomach and esophagus — allowing acid to flow back up. This directly explains the burning in both the throat/chest and upper stomach. The fact that she feels it from food she previously tolerated confirms that her baseline mucosal sensitivity has increased since starting the medication.

**Mechanism 2 — All medications taken together on an empty stomach**
She is currently taking all four medications together in the morning before eating. This is the correct approach only for Euthyrox — the other three (oral estradiol, multivitamin, B vitamin) are stomach irritants that require food as a buffer. Taking them on an empty stomach concentrates their irritant effect directly on the gastric and esophageal lining with nothing to neutralise them. This is very likely amplifying the GERD effect significantly.

Additionally, multivitamins containing calcium or iron — taken at the same time as Euthyrox — actively block Euthyrox absorption. They must be separated by at least 4 hours.

### Recommended Medication Schedule
| Time | Medication | Reason |
|---|---|---|
| Morning, empty stomach | **Euthyrox only** | Must be taken alone, fasted |
| 30–60 min later | **Breakfast** | Then eat normally |
| With breakfast or lunch | **Oral estradiol (Progyn Intim)** | Reduces GI irritation; taken with food |
| With lunch or dinner | **Multivitamin + B vitamin** | At least 4 hours from Euthyrox; with food |

### Important Drug Interaction: Oral Estradiol + Euthyrox
Oral estradiol raises thyroxine-binding globulin (TBG) in the liver, which binds more of the circulating T4 and reduces the free, bioactive fraction. This means that starting oral estradiol partially counteracts the Euthyrox dose increase — the two changes were made simultaneously, making the net thyroid effect unpredictable. A TSH recheck is recommended approximately 12 weeks after both changes to confirm levels have landed where intended.

### Recommended Questions for Doctor
1. *"She is currently taking all medications together on an empty stomach. Should the oral estradiol and vitamins be taken with food instead, and separated from Euthyrox by at least 4 hours?"*
2. *"She has developed constant nausea, one vomiting episode, and burning in the throat and stomach from food she previously tolerated. Could the oral estradiol be causing GERD by relaxing the lower esophageal sphincter? Would a dose review or timing change be expected to help?"*
3. *"Was the Euthyrox dose increase to 75mcg made with awareness that oral estradiol would also be started? Given the TBG interaction, is a TSH recheck planned at approximately 12 weeks?"*

---

## 4. Other Abnormal Results — Context & Questions

### Persistently Elevated TSH (5.5 mUI/L, normal 0.35–4.5)
- Elevated across two readings (5.9 in Sept 2025, 5.5 in Feb 2026)
- T4 free is normal (0.9 ng/dL)
- Thyroid antibodies are negative (rules out Hashimoto's autoimmune thyroiditis)
- Being followed by Dr Makke
- **Subclinical hypothyroidism** is the likely diagnosis — worth asking about treatment threshold

### Elevated Prolactin (34.8 ng/mL, normal 5.2–26.5)
- Confirmed active prolactin after PEG test (not macro-prolactin artefact)
- History of very high prolactin in 2023 (91.4 ng/mL) — significant improvement
- Rathke's cleft cyst on pituitary is a known structural explanation
- Worth asking if levels are being monitored in relation to the cyst

### Low Vitamin D (27.5 ng/mL, normal >30) + Elevated PTH (38.4 pg/mL, normal 6.5–36.8)
- Classic secondary hyperparathyroidism pattern: low Vit D → PTH rises to compensate
- Straightforward to address with Vitamin D supplementation
- **Recommended question:** *"Should she start Vitamin D supplementation to bring levels above 30, and would that be expected to normalise the PTH?"*

### Low Folate + Low-Normal Ferritin
- Both likely connected to the Mounjaro weight loss period
- Folate below range is confirmed and should be supplemented
- Also linked to the tongue inflammation (see above)
- **Recommended question:** *"Should she be on folate supplementation, and should ferritin be monitored more closely given the downward trend (22 → 13 → 11)?"*

### Recurrent UTI
- E. coli, resistant to Ampicillin and Ciprofloxacin
- Has been recurring for ~3 years
- Sensitive to: Amoxicillin/clavulanic acid, Nitrofurantoin, Fosfomycin, TMP/SMX, all cephalosporins
- **Recommended question:** *"Given the multi-year recurrence, is there a plan to investigate the underlying cause (e.g. structural, microbiome, immune) rather than just treating each episode?"*

---

## 5. Bilateral Arm Burning & Itching — Neurological Assessment

### Current Symptom Profile
- Right arm weakness/pain ongoing for 3 months; right leg still painful as of last week (not resolved)
- Bilateral arm burning for ~4 weeks — whole arm, strongest at upper arms, present throughout
- Buttocks burning — new; worse with sitting, better lying flat; piriformis self-test negative
- No visible skin change on arms at any point
- All symptoms progressive — not resolving

### Clinical Self-Tests Performed (April 2026)

| Test | Result | Interpretation |
|---|---|---|
| Lhermitte's sign (chin to chest) | ✅ Negative | No electric shock. Reassuring — reduces likelihood of acute significant cord compression |
| Arm abduction relief (hand on head) | Negative | No symptom change. Doesn't rule out radiculopathy (low sensitivity test) |
| Piriformis FAIR test (cross-body knee) | ✅ Negative | Buttocks burning not from piriformis. Source is likely lumbar/lower spine |
| Grip and release (fist × 10 sec) | ✅ 26 cycles | Above normal threshold of 20. Normal fine motor — reassuring against significant myelopathy |
| Sitting vs lying (buttocks pain) | ⚠️ Worse sitting | Lumbar/lower spinal pressure pattern for the buttocks symptom |

**Overall self-test interpretation:** The negative Lhermitte's and normal grip test are the two most meaningful results — they point away from acute, significant cervical cord compression right now. The sitting-worsening buttocks symptom with a negative piriformis test suggests a lumbar/lower spinal contribution to that symptom specifically. The most coherent picture is **multi-level spinal involvement** (cervical + lumbar) without acute cord damage currently detectable by clinical signs.

---

### Why the Hands + Upper Arms (Sparing Forearms) Distribution Is Critical

This is not a random pattern. In neurology, the location of symptoms maps precisely to specific nerve levels. Simple peripheral neuropathy from nutritional deficiency starts at the extremities and works inward — it does not typically spare the middle portion of the limb while affecting both ends.

Affecting hands AND upper arms near the shoulder while the **forearms are relatively spared** points to one of two things:

1. **Multiple nerve roots compressed simultaneously** (C5 for upper arm/shoulder + C8/T1 for hands), skipping the mid-arm roots (C6/C7 which serve the forearm)
2. **Spinal cord compression itself** — which produces a "cape-like" or non-dermatomal distribution because the cord organises fibres differently from individual nerve roots

Combined with her existing documented right arm and leg weakness, these symptoms should be considered together as a potentially evolving neurological picture — not as separate problems.

---

### Condition A: Cervical Myelopathy — Full Analysis

#### What it is
Cervical myelopathy is compression of the **spinal cord itself** within the neck. It is the most serious of the two conditions and is distinct from a pinched nerve. When the spinal cord is compressed, it affects the "highway" between the brain and the body — meaning symptoms can appear in the arms, legs, hands, and even bladder/bowel function simultaneously.

#### How dangerous is it?
It is serious and requires urgent attention. Left untreated, cervical myelopathy can worsen and cause permanent spinal cord injury and paralysis. In non-operative patients, the prognosis is poor — 75% of untreated patients experience episodic neurological deterioration, 20% have slowly progressive decline, and only 5% have rapid onset. None of 120 non-operative patients in one landmark study experienced complete recovery.

A poor prognosis is specifically associated with more than 18 months of symptomatic duration — and especially in women. The timeliness of intervention is critical: patients with milder myelopathy and shorter preoperative symptom duration tend to have significantly improved outcomes after surgery.

The key danger is that some neurological damage from spinal cord compression can become **permanent** even after surgery — meaning the longer it goes untreated, the more likely there is irreversible damage. Some progression can be irreversible even with treatment, which is why it is important to stop any progression when identified in the mild stages.

#### What causes it?
The most common cause is gradual degeneration of the cervical spine — herniated discs, bone spurs (osteophytes), and narrowing of the spinal canal. Some people are born with a naturally narrow spinal canal (congenital spinal stenosis) and experience myelopathy sooner than others when further narrowing occurs. Ligament hardening (ossification) is another cause.

In her specific case — 41 years old, female, with documented musculoskeletal imbalance (one leg shorter, physiotherapist found spinal compensation) — the most plausible causes in rough order are:

- **Disc herniation** — a central (midline) disc herniation compresses the cord directly. This is the most common cause in younger patients under 55.
- **Congenital narrow canal** — some people are simply born with less space for the cord; when any compression is added, symptoms begin earlier than expected for their age
- **Degenerative changes accelerated by musculoskeletal imbalance** — her leg length discrepancy causes compensatory loading throughout the spine, which can accelerate disc wear at specific levels
- **Post-partum changes** — the ligament laxity of pregnancy (which persists for up to a year) can allow spinal instability and disc herniation

Degenerative changes typically occur at the C5-C6 or C6-C7 levels, where increased segmental mobility places the greatest mechanical stress on the cervical spine.

#### Is it fixable?
Yes — **but timing matters enormously**. Surgical decompression can prevent the progression of myelopathy and improve neurological status, functional outcomes, and quality of life.

Surgical options include:
- **ACDF (Anterior Cervical Discectomy and Fusion)** — the most common approach for 1-2 compressed levels. The surgeon removes the damaged disc from the front of the neck and fuses the adjacent vertebrae. ACDF has the lowest overall complication rate (3.9%) and zero reported mortality in recent comparative data, with the shortest hospital stay.
- **Laminoplasty** — a posterior approach that widens the spinal canal by restructuring the bone at the back of the neck. Used for multiple levels.
- **Laminectomy with fusion** — a more extensive posterior decompression for complex cases.

The outcome for patients who are treated while still in the mild-to-moderate stage is generally very good — most patients stabilise or improve. The goal of surgery is to stop further damage; some existing symptoms may also improve, but complete resolution of pre-existing damage is not guaranteed.

**What happens without surgery?** Without treatment, myelopathy typically progresses — either gradually or in sudden steps. Conservative management (physical therapy, bracing) can reduce pain but does not decompress the spinal cord and **cannot stop the progression**. Crucially, spinal manipulation by chiropractors or aggressive traction is **contraindicated** in myelopathy and can cause acute worsening.

---

### Condition B: Cervical Radiculopathy — Full Analysis

#### What it is
Cervical radiculopathy is compression of individual **nerve roots** as they branch away from the spinal cord — commonly called a "pinched nerve." It is distinct from myelopathy: the spinal cord itself is not compressed, only the nerve root at the point where it exits the spine. Symptoms follow a specific dermatomal (nerve territory) distribution.

#### How dangerous is it?
Much less dangerous than myelopathy. All forms of radiculopathy are very treatable and very rarely require surgery — most patients make a full recovery with conservative treatment and time. It does not carry the risk of paralysis that myelopathy does. However, bilateral radiculopathy (affecting both sides) is a more serious presentation than unilateral, as it suggests more central compression. Spinal cord compression must be suspected when bilateral symptoms, gait disturbance, or systemic signs accompany radicular complaints — and MRI is mandatory in these scenarios.

#### What causes it?
The same structural causes as myelopathy, but the disc herniation or bone spur is positioned laterally rather than centrally — compressing the exiting nerve root rather than the cord. In younger patients, acute disc herniation is the most common cause. In younger people, cervical radiculopathy is most often caused by a sudden injury resulting in a herniated disc. In older people, degenerative changes such as arthritis are more common.

For bilateral radiculopathy (both sides), the compression must be centrally located enough to affect both sides — which means it is closer to the cord, and the boundary between radiculopathy and myelopathy becomes less clear.

#### Is it fixable?
Yes, and with a better prognosis than myelopathy. The prognosis for acute cervical radiculopathy is good, with 90% of patients improving with medical and rehabilitative treatment. Clinical improvements are observed within 4-6 months of onset, and full recovery can occur over the course of two to three years.

Non-surgical treatment options include:
- Physical therapy (gentle strengthening and mobilisation — not manipulation)
- NSAIDs and muscle relaxants for pain management
- A soft cervical collar for short-term rest
- Epidural steroid injections (effective in 40-84% of patients) for persistent cases

Surgery is considered if symptoms persist after 6-12 weeks of non-surgical care, or if there is progressive neurological deficit.

---

### Important Additional Possibility: Multiple Sclerosis — Reduced But Not Eliminated

A brain MRI performed approximately two weeks ago (pituitary-focused, general brain appearance clear) significantly reduces the probability of MS, but does not entirely eliminate it. Here is why:

Classic MS almost always produces white matter lesions in the brain by the time spinal cord symptoms are present. A clear brain MRI therefore makes MS considerably less likely than it would otherwise be. However:

- The brain MRI was focused on the pituitary gland — it may not have been optimised with the specific sequences (e.g. FLAIR) used to detect MS plaques
- Very early or purely spinal MS (without brain involvement) is rare but documented
- The cervical spinal cord itself has not been imaged

**Practical implication:** MS is now a lower-probability consideration, but it should still be formally excluded with a cervical spine MRI using appropriate sequences. A clear cervical cord MRI would effectively rule MS out in the context of an already clear brain MRI.

For completeness, MS symptoms include tingling, numbness, pain, burning, and itching in the arms, legs, trunk, or face — and women are three times more likely to have MS than men, with first symptoms typically between ages 20 and 40. A published case series found that paroxysmal itching in the upper extremity corresponding to cervical dermatomes is a documented presenting symptom of MS caused by spinal cord lesions. This remains worth knowing about, but the clear brain MRI meaningfully shifts the balance toward structural cervical spine pathology.

---

### The Accumulating Neurological Picture

| Symptom | When | Significance |
|---|---|---|
| Right arm and leg weakness/pain | 3 months ago, ongoing | Same-side arm + leg = cord-level involvement most likely |
| Transient right leg numbness on standing | 3 months ago | Possible cord or vascular involvement |
| Bilateral arm burning | 4 weeks ago, ongoing | Bilateral sensory involvement — whole arm, strongest upper arm |
| Buttocks burning | Recent | Worse sitting, piriformis negative → lumbar/lower spinal source |

### Probability Estimates — Updated After Self-Tests

| Scenario | Probability | Key reasoning |
|---|---|---|
| **Cervical disc herniation + lumbar involvement** (mechanical, potentially reversible) | ~55% | Negative Lhermitte's, normal grip test, sitting-worsens buttocks all support this. Most optimistic scenario — many cases resolve conservatively |
| **Cervical myelopathy** (more established cord compression) | ~15% | Negative Lhermitte's and normal grip test reduce this meaningfully from earlier estimates |
| **Multi-level stenosis** (structural, more widespread) | ~15% | Still explains the full-body spread; would need full-spine MRI to evaluate |
| **MS or inflammatory spinal cord disease** | ~8% | Reduced by clear brain MRI; still needs cervical cord MRI to formally exclude |
| **Pure musculoskeletal** | ~7% | Piriformis negative reduces this; right arm + right leg together is hard to explain purely musculoskeletally |

### What Needs to Happen

A **cervical and lumbar spine MRI** (full spine preferred) is the essential next step. It will show:
- Disc herniation at cervical or lumbar levels
- Spinal canal narrowing
- Signal changes within the cord (if any)
- Demyelinating lesions (MS plaques in the cord)

**Brain MRI was clear two weeks ago** — this is reassuring and reduces MS probability. The cervical and lumbar cord have not been imaged.

### Safe Immediate Steps While Awaiting MRI
1. **Avoid prolonged sitting** — take breaks every 20–30 minutes; use a cushion
2. **Sleep position** — flat on back with pillow under knees, or side-lying with pillow between knees
3. **Avoid neck extension** (looking up, tilting head back) — this compresses posterior cervical structures
4. **No neck manipulation** — chiropractic cracking or aggressive traction contraindicated until MRI done
5. **Short course of anti-inflammatories** (ibuprofen with food, if no contraindications) — reduces nerve root inflammation

---

### What Needs to Happen — Urgently

**Cervical MRI is the essential next step.** It will show:
- Disc herniation or bone spurs compressing the cord or nerve roots
- Spinal canal narrowing (stenosis)
- Signal changes within the cord itself (indicating damage)
- Demyelinating lesions (MS plaques)

**Brain MRI was performed approximately two weeks ago (pituitary-focused, general brain appearance clear) — this significantly reduces the likelihood of MS but does not image the cervical spinal cord itself.**

### Recommended Questions for Doctor
1. *"She has bilateral arm burning for 4 weeks, right arm and right leg ongoing weakness/pain for 3 months, and new buttocks burning worse with sitting. Her brain MRI was clear but the cervical and lumbar spine have not been imaged. Could she be referred for an urgent cervical and lumbar spine MRI?"*
2. *"Clinical self-tests show negative Lhermitte's and normal grip test — but the pattern of right arm + right leg together with bilateral arm spread still warrants imaging. The original neurologist attributed everything to the knee surgery, which does not account for the current picture. Should she be re-assessed neurologically?"*
3. *"The buttocks burning worsens with sitting and piriformis self-test is negative — is this likely a lumbar nerve root contribution from her known leg length discrepancy and spinal imbalance?"*

---

## 6. Overall Summary & Priority Questions for Next Appointment

### Priority 0 — Urgent: Nausea, Vomiting & Burning (contact doctor before next appointment)
> *"Since starting the new medications one week ago she has developed constant nausea, vomited once, and now has burning in the throat and stomach from mildly spicy food she previously tolerated. She is currently taking all medications together on an empty stomach. Should Progyn Intim and the vitamins be taken with food and separated from Euthyrox by at least 4 hours? Could the oral estradiol be causing GERD?"*

### 🚨 Priority 1 — Urgent: Full Spine MRI + Neurological Re-assessment
> *"She has right arm and right leg weakness/pain ongoing for 3 months, bilateral arm burning for 4 weeks, and new buttocks burning worse with sitting. Her brain MRI was clear but no spinal imaging has been done. Clinical self-tests show negative Lhermitte's and normal grip test — somewhat reassuring — but the right arm + right leg together with bilateral arm spread still requires imaging to explain. She needs an urgent cervical and lumbar spine MRI, and a neurological re-assessment with the full symptom picture presented rather than just the original knee surgery attribution."*

### Priority 2 — CA 72-4 Follow-up
> *"All her other tumour markers are completely normal. Her CA 72-4 is mildly elevated at 10.8 — in the lowest elevation band. She has an active recurring E. coli UTI, which studies show is present in 60% of false positive CA 72-4 cases at this level. Can we retest after the UTI is fully resolved before pursuing more invasive investigations?"*

### Priority 3 — Nutritional Deficiencies
> *"Her folate is below range, ferritin is trending down to 11, and B12 is at the low-normal end. These may be driving her recurring tongue inflammation and possibly her arm itching/burning. Should she be supplementing folate and Vitamin D at minimum, and should B12 be monitored more closely?"*

### Priority 4 — Thyroid + Estradiol Interaction
> *"She has now started both a higher Euthyrox dose (50→75mcg) and oral estradiol simultaneously. Oral estradiol raises TBG and reduces free T4, partially counteracting the dose increase. Was this interaction accounted for, and is a TSH recheck planned at ~12 weeks?"*

### Priority 5 — Recurrent UTI
> *"This has been recurring for 3 years. Is there a plan to investigate the root cause rather than just treating each episode?"*

### Priority 6 — Oral Thrush
> *"The dentist assessed her tongue as consistent with oral thrush. Should she be treated with antifungals, and is there a preventive strategy given it likely recurs each time she takes antibiotics for her UTI?"*
